#!/bin/bash

# ---------- DESCRIPTION -----------
#
# This script installs HomeLab-pH software for Raspberry Pi.
# Modules and pkgs to install: bc apache i2c_bcm2708 i2c-dev i2c-tools w1-gpio w1-therm.
# Supported OS: Raspbian, Ubuntu Mate.
#
# -------------- end ---------------


# --------- USER SETTINGS ----------
#
# This script may be executed with an argument, either "--disable-pum" or "--enable-pum".
# The argument will either disable the Periodic Unassisted Measurements or enable the 
# option to set them. If invalid or no argument is provided, the user will be asked to 
# decide interactively. 
#
# To change the default GPIOs uncomment the following lines.
# If the lines are left commented GPIOs to be used are:
#   - the GPIOs which numbers are set by a previous installation (first choice if present) or
#   - (second choice) GPIO 4 for the temperature sensor and GPIO 15 for the on-board button/LED.
# Valid Raspberry Pi GPIO numbers are 2 through 27.
# -----------             -----------
#
# t_sensor_gpio_number=4 # Number of the GPIO to read the temperature sensor.
# button_gpio_number=15 # Number of the GPIO to communicate the on-board button and LED.
#
# ------ end of user settings ------

regex_GPIO_RPi='([2-9]|1[0-9]|2[0-7])'
regex_clock_hours='(1?[0-9]|2[0-3])'
server_user='www-data'
script_owner=$(stat -c '%U' $0)
os_reload=0
homelab_root='/var/www/homelab'
server_ports_file='/etc/apache2/ports.conf'
load_modules_file='/etc/modules'
groups_file='/etc/group'
installation_log_file='installation.log'
server_virtual_host_file='/etc/apache2/sites-available/homelab'
virtual_host_template='virtual_host_config'
times_port_80=0
function apache_to_port_80 {
	((times_port_80++))
	if [ $times_port_80 -gt 3 ]; then print_exit "Apache service is ON but script can not access it. Uninstall Apache manually and try again.\nInstallation failed." 'exit'; fi
	echo "GET / HTTP/1.0\r\n\r\n" | nc localhost 80 >/dev/null
	if [ $? -gt 0 ]; then
		service apache2 start &>/dev/null
		if [ $? -gt 0 ]; then
			try_install_apache
		else
			apache_to_port_80
		fi
	else
		echo "GET / HTTP/1.0\r\n\r\n" | nc localhost 80 | grep "Server: Apache/" >/dev/null
		if [ $? -gt 0 ]; then print_exit "Can not set Apache as a default server. Installation failed." 'exit'; fi
	fi
}
function try_install_apache {
	if [ $apache_installed_now -eq 0 ]; then
		apt-get install apache2 -y
		if [ $? -gt 0 ]; then print_exit "Can not install Apache. Installation failed." 'exit'; fi
		apache_installed_now=1
		apache_to_port_80
	else
		print_exit "Can not set Apache either as a default server or as a service. Installation failed." 'exit'
	fi
}
function print_exit {
	printf "\n$1" &>> $installation_log_file
	if [ "$2" != 'skip' -a "$3" != 'skip' ]; then printf "\n$1\n"; fi
	if [ "$2" == 'exit' -o "$3" == 'exit' ]; then exit 1; fi
}
function load_module {
	modprobe $1
	if [ $? -gt 0 ]; then
		printf "\nCan not load module $1. Installation failed.\n"
		exit 1
	fi
	egrep -i "^$1" $load_modules_file >/dev/null
	if [ $? -gt 0 ]; then modules_string=$modules_string"\n$1"; fi
}
function RAM_disk {
	local size=1m # RAM disk size
	local target_file=/etc/fstab # register here to make the disk on boot
	local RAMpath=$1
	grep -e $RAMpath -i $target_file >/dev/null
	if [ $? -gt 0 ]; then
		printf '\ntmpfs '$RAMpath' tmpfs nodev,nosuid,size='$size' 0 0' >> $target_file
		if [ $? -gt 0 ]; then return 1; fi
		fstab=true
	fi
	mount -t tmpfs -o size=$size tmpfs $RAMpath
	if [ $? -gt 0 ]; then # mount not successful 
		if [ ! -z ${fstab+x} ]; then sed -i "\|$RAMpath|d" $target_file; fi # remove the line added earlier in $target_file
		return 2
	fi
	return 0
}
cronjob='remove'
case $1 in 
	--enable-pum)
		cronjob='set'
		;;
	--disable-pum)
		;;
	*)
		echo 
		tput smso
		printf "Do you want PUM (periodic unassisted measurements) be available? \n[y/N] "
		tput rmso
		read -r -p "" response
		if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]; then cronjob='set'; fi
		;;
esac
command -v realpath
if [ $? -eq 0 ]; then
	current_dir=$(dirname $(realpath -s $0))
else
	current_dir=$(dirname "$0")
fi
cd $current_dir;
chmod 666 $installation_log_file
printf "HomeLab-pH installation\n$(date)\nSoftware version: $(head -n 1 version)" > $installation_log_file
if [ $? -gt 0 ]; then echo "Can not log data to '$installation_log_file'."; fi
chmod 666 $installation_log_file
chown $script_owner:$script_owner $installation_log_file
print_exit "\nSystem: $(uname -a)" 'skip'
os=$(grep -E '^ID=' /etc/os-release)
os=${os/ID=/}
case $os in
	raspbian)
		os='debian'
		supported_versions=" 7.8 8+ " # removed 7.6
		os_version="$(cat /etc/debian_version)"
		IFS='.' read -r -a os_version_arr <<< "$os_version"
		if [[ ${os_version_arr[0]} -gt 7 ]]; then version_supported=1; fi
		;;
	ubuntu)
		supported_versions=" 16.04 18.04 "
		os_version="$(gawk -F= '/^DISTRIB_RELEASE=/{print $2}' /etc/lsb-release)"
		;;
	*)
		print_exit "This is unsupported OS.\nSuported are Ubuntu and Raspbian.\nInstallation failed." 'exit'
		;;
esac
hour=$(grep -oP "^\s*cron_new_log_at=$regex_clock_hours?(\s+|$)" $homelab_root'/cgi-bin/cron_config.sh' 2>/dev/null | cut -d = -f 2)
if [[ ! -z "$hour" ]]; then 
	chmod 777 $current_dir'/site/cgi-bin/cron_config.sh'
	sed -i "s/cron_new_log_at=.*/cron_new_log_at=$hour/" $current_dir'/site/cgi-bin/cron_config.sh'
fi
if [[ "$supported_versions" =~ " $os_version " ]]; then version_supported=1; fi
if ! [[ "$version_supported" ]]; then
	print_exit "This is unsupported $os version.\nSuported versions are:$supported_versions\nInstallation failed." 'exit'
fi
print_exit "$os version is $os_version"
i2c_bus_number=1
button_gpio_number=15 
main_config_file=$current_dir'/site/cgi-bin/main_config.sh'
pin=$(grep -oP "^\s*GPIO_number_button=$regex_GPIO_RPi?(\s+|$)" $homelab_root'/cgi-bin/main_config.sh' 2>/dev/null | cut -d = -f 2)
if [[ ! -z "$pin" && "$pin" -ne "$button_gpio_number" ]]; then button_gpio_number=$pin; fi
chmod 755 $main_config_file
sed -i '/# added during installation/,$d' $main_config_file # delete the 'during installation' section
printf "\n# added during installation" >> $main_config_file
printf "\ni2c_bus_number=$i2c_bus_number" &>> $main_config_file
printf "\nGPIO_number_button=$button_gpio_number\n" &>> $main_config_file
printf "GPIO_button=\$gpio_path'/gpio'\$GPIO_number_button" &>> $main_config_file
cp -f version site/ui/
printf "\nBash version is $BASH_VERSION" &>> $installation_log_file
printf "\nCurrent directory is $current_dir" &>> $installation_log_file
egrep -i "^gpio:" $groups_file >/dev/null
if [ $? -gt 0 ]; then print_exit "No group 'gpio'. Installation failed." 'exit'; fi
egrep -i "^i2c:" $groups_file >/dev/null
if [ $? -gt 0 ]; then
	groupadd i2c
	print_exit "Group 'i2c' added."
	os_reload=1
fi
apt-get update
echo
echo '-------- Apache begin ---------'
echo
apache_installed_now=0
apache_to_port_80
ls /etc/init.d/ | grep "^apache2$" >/dev/null
if [ $? -gt 0 ]; then try_install_apache; fi
apache_ver=$(apache2 -v)
printf "\n$apache_ver" &>> $installation_log_file
apache_version=`expr match "$apache_ver" '.*Apache/\([[:digit:]]\.[[:digit:]]\).*'`
if [ "$apache_version" == "2.4" ]; then
	server_virtual_host_file='/etc/apache2/sites-available/homelab.conf'
	virtual_host_template='virtual_host_config_Apache_v2.4'
fi
if [ ! -e "/etc/apache2/mods-enabled/cgid.load" ] && [ ! -e "/etc/apache2/mods-enabled/cgi.load" ]; then
	echo '-- enabling Apache cgi_mod --'
	a2enmod cgi >/dev/null
	echo 
fi
grep $server_user $groups_file >/dev/null
if [ $? -gt 0 ]; then print_exit "No apache user '$server_user'. Installation failed." 'exit'; fi
cp $virtual_host_template $server_virtual_host_file
if [ $? -gt 0 ]; then print_exit "Can not write to '$server_virtual_host_file'. Installation failed." 'exit'; fi
a2ensite homelab
a2enmod include
grep 'Listen 7223' $server_ports_file >/dev/null
if [ $? -eq 1 ]; then
	printf "\n\n# --- HomeLab-pH installation ---\nNameVirtualHost *:7223\nListen 7223\n# ------\n" >> $server_ports_file
	if [ $? -gt 0 ]; then print_exit "Can not write to $server_ports_file. Installation failed." 'exit'; fi
fi
usermod -a -G i2c $server_user
usermod -a -G gpio $server_user
service apache2 restart
if [ $? -gt 0 ]; then print_exit "Can not start Apache. Installation failed." 'exit'; fi
if [ ! -z "$apache_installed_now" ]; then
	echo
	echo '---^^^--- Apache end ---^^^---'
	echo
fi
usermod -a -G i2c $USER
usermod -a -G gpio $USER
apt-get install bc
if [ $? -gt 0 ]; then print_exit "Can not install bc. Installation failed." 'exit'; fi
data_directory=$homelab_root'/cgi-bin/data'
data2_dir=$homelab_root'/cgi-bin/data2'
thingspeak_dir=$homelab_root'/cron/thingspeak'
install_data2_dir=$current_dir'/site/cgi-bin/data2'
install_data_dir=$current_dir'/site/cgi-bin/data'
install_cron_dir=$current_dir'/site/cron'
rm -rf $install_data2_dir
mkdir -p $install_data2_dir 
rm -f -R $install_data_dir
mkdir -p $install_data_dir'/cron/log/'
mkdir -p $install_data_dir'/log/'
if [ -d "$data_directory" ]; then # copy user files to data directory
	cp -R --preserve=all $data_directory'/'* $install_data_dir
	rm -f $install_data_dir'/load_time_config.sh' 2>/dev/null # clear from older versions; now moved to data2
fi
chmod u+w $install_cron_dir'/cron_more.sh' 2>/dev/null
cp $homelab_root'/cron/cron_more.sh' $install_cron_dir 2>/dev/null
cp $thingspeak_dir'/error.log' $install_cron_dir'/thingspeak/error.log' 2>/dev/null # 
cp $thingspeak_dir'/channel_config.sh' $install_cron_dir'/thingspeak/channel_config.sh' 2>/dev/null
sudo umount $data2_dir # prepare to delete $homelab_root
rm -R -f $homelab_root
mkdir -p $data2_dir # ??
cp -R --preserve=all site/* $homelab_root
if [ $? -gt 0 ]; then print_exit "Can not write to $homelab_root. Installation failed." 'exit'; fi
chown -R --reference=$0 $homelab_root
chmod -R 555 $homelab_root'/cgi-bin' $homelab_root'/cron'
chmod u+w $homelab_root'/cron' $thingspeak_dir $thingspeak_dir'/channel_config.sh' $homelab_root'/cron/cron_more.sh'
chmod -R 644 $data_directory
chmod 755 $homelab_root $homelab_root'/cgi-bin' $data_directory $data_directory'/log' $data_directory'/cron' $data_directory'/cron/log'
chmod -R 444 $homelab_root'/ui'
chmod 555 $homelab_root'/ui' $homelab_root'/ui/images' $homelab_root'/ui/scripts' $homelab_root'/ui/styles'
chmod -R 1777 $data2_dir
[[ -f $thingspeak_dir'/error.log' ]] && chmod 644 $thingspeak_dir'/error.log'
[[ -f $homelab_root'/cgi-bin/data/cron/cron_last' ]] && chmod 644 $homelab_root'/cgi-bin/data/cron/cron_last'
find $data2_dir -type f -exec chmod 0644 -- {} + # ??
chown -R $server_user:$server_user $data_directory $data2_dir
function show_to_user {
	printf "\n$1" &>> $installation_log_file
	echo $1
}
crontab -l -u www-data > backup_crontab # backup current crontab for www-data
chmod u+x $install_cron_dir'/set_cron.sh'
cron_flag=$data_directory'/cron/running'
$install_cron_dir'/set_cron.sh' -c -q
if [[ $? -eq 0 ]]; then
	show_to_user 'Warning. Cron job is active.'
	$install_cron_dir'/set_cron.sh' -r -q
	if [[ $? -ne 1 ]]; then
		show_to_user 'Error. Can not clear the cron job.'
	else
		show_to_user 'The cron job is cleared.'
		rm $cron_flag
	fi
fi
$install_cron_dir'/set_cron.sh' -c -q
if [ $? -eq 1 ] && [ "$cronjob" == "set" ]; then
	$install_cron_dir'/set_cron.sh' -s -q
	if [[ $? -eq 0 ]]; then
		show_to_user 'A new cron job is added to crontab.'
		touch $cron_flag
		logged_user=$(logname)
		chown $logged_user:$logged_user $cron_flag
	else 
		show_to_user 'Error. Can not add the cron job.'
	fi
fi
if [[ ! $t_sensor_gpio_number =~ ^$regex_GPIO_RPi$ ]]; then t_sensor_gpio_number=4; fi
RPi_config_file='/boot/config.txt'
t_sensor_gpio_str='dtoverlay=w1-gpio,gpiopin='
start_str='# --- HomeLab-pH installation ---'
end_str='# ------'
start_line=$(grep -n "$start_str" $RPi_config_file | cut -d : -f 1)
if [ "$start_line" != "" ]; then
	end_line=$(grep -n "$end_str" $RPi_config_file | cut -d : -f 1)
	nu=$(head -n +$end_line $RPi_config_file | tail -n +$start_line | grep -oP "$t_sensor_gpio_str$regex_GPIO_RPi?" | cut -d = -f 3) # t-sensor gpio number 
	if [[ ! -z "$nu" && "$nu" -ne "$t_sensor_gpio_number" ]]; then
		ln=$(head -n +$end_line $RPi_config_file | tail -n +$start_line | grep -n "$t_sensor_gpio_str" | cut -d : -f 1)
		ln=$((start_line+ln-1)) # the pin declaration line number 
		t_sensor_gpio_str+=$nu;
		sed --in-place=.backup $ln"s/.*/$t_sensor_gpio_str/" $RPi_config_file # declaration with the new pin 
		if [ $? -gt 0 ]; then print_exit "Can not write to $RPi_config_file. Installation failed." 'exit'; fi
		os_reload=1
	fi
else
	modify_config_file=''
	egrep -i "^dtparam=i2c_arm=on" $RPi_config_file >/dev/null
	if [ $? -gt 0 ]; then modify_config_file=$modify_config_file'\ndtparam=i2c_arm=on'; fi
	egrep -i "^$t_sensor_gpio_str$t_sensor_gpio_number" $RPi_config_file >/dev/null
	if [ $? -gt 0 ]; then modify_config_file=$modify_config_file'\ndtoverlay=w1-gpio,gpiopin=4'; fi
	if [ ${#modify_config_file} -gt 0 ]; then
		printf "\n\n$start_str$modify_config_file\n$end_str\n" >> $RPi_config_file
		if [ $? -gt 0 ]; then print_exit "Can not write to $RPi_config_file. Installation failed." 'exit'; fi
		os_reload=1
	fi
fi
modules_string=''
load_module i2c_bcm2708
load_module i2c_dev
load_module w1_gpio
load_module w1_therm
if [ ${#modules_string} -gt 0 ]; then
	printf "\n\n# --- HomeLab-pH installation ---$modules_string\n# ------\n" >> $load_modules_file
	if [ $? -gt 0 ]; then print_exit "Can not write to $load_modules_file. Installation failed." 'exit'; fi
fi
apt-get -y install i2c-tools --no-install-recommends # --no-install-recommends to prevent debian stretch (9.1) from installing read-edid
if [ $? -gt 0 ]; then print_exit "Can not install i2c-tools. Installation failed." 'exit'; fi
RAM_disk $data2_dir
if [ $? -gt 0 ]; then
	print_exit "Warning. Mounting a RAM disk failed."
else
	chmod 1777 $data2_dir
fi
addr=$(ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | cut -f1  -d'/')
print_exit "Server address is $addr:7223\nInstallation finished." 'skip'
COLOR='\033[1;33m'
NC='\033[0m'
if [ $os_reload -eq 1 ]; then
	printf "\nThe system has to be restarted to finalize the installation."
	printf "\nWhen restarted point your browser to ${COLOR}http://$addr:7223${NC}\n"
	read -r -p "Restart now? [y/N] " response
	if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]; then reboot; fi
else
	printf "\nInstallation finished. Point your browser to ${COLOR}http://$addr:7223${NC}\n"
fi