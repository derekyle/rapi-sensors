#!/bin/bash
#
# adds to crontab a cron job for PUM
# execute with sudo

cd $(dirname "$0")
./unset.sh
server_user=www-data
cron_flag='/var/www/homelab/cgi-bin/data/cron/running'
./set_cron.sh -c -q
if [ $? -eq 1 ]; then
	./set_cron.sh -s -q
	if [[ $? -eq 0 ]]; then
		echo 'A new cron job is added to crontab.'
		touch $cron_flag
		logged_user=$(logname)
		chown $logged_user:$logged_user $cron_flag
	else 
		echo 'Error. Can not add cron job for '$server_user'.'
		exit 1
	fi
else
	echo 'Error. A cron job already set for '$server_user'. Will not overwrite.'
	exit 1
fi
exit 0
