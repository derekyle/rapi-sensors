#!/bin/bash

# HomeLab-pH module unattended measurement; to be evoked by a crontab job
# exit codes: 0,1,2,3,4
# code 0 Success or no PUM job is set or not the time for file rotation
# code 1 Invalid start measurement hour
# code 2 Invalid file rotation hour
# code 3 Can not write data to '$cron_cfg'.'
# code 4 Can not write data to '$cron_dir'/cron_last.'

# change to this file directory
command -v realpath
if [ $? -eq 0 ]; then
	cd $(dirname $(realpath -s $0))
else
	cd $(dirname "$0")
fi

. /var/www/homelab/cgi-bin/cron_config.sh # sets $cron_cfg, $allowed_cron_intervals, $cron_dir, $cron_log_string $cron_new_log_at 
[ ! -f $cron_cfg ] && exit 0 # the file is missing as the user did not set a PUM job

if [ ! -d $cron_dir'/log' ]; then mkdir -p $cron_dir'/log'; fi

cfg=$(cat $cron_cfg)
for i in id interval aPointAt newLog24 description; do # set $interval, $id, $description, $aPointAt, $newLog24
	item=${cfg/*$i\":/}
	item=${item/\"/}
	item=${item/[,\}]*/}
	item=${item/\"/}
	declare "${i}"="$item"
done

if [[ ! "$allowed_cron_intervals" =~ " $interval " ]]; then exit 1; fi # validate $interval
((a=$aPointAt % 3600))
if [ "$a" -ne 0 ]; then exit 1; fi # invalid $aPointAt

now=$(date +%s)
TZ=$(date +"%-z") # time zone string; %-z scraps one zero after +/- sign, if any
TZh=$(( TZ/100*3600 )) # hours component of time zone in seconds
TZm=$(( TZ%100*60 )) # minutes component of time zone in seconds
t=$(( ( now - (aPointAt-TZm) - (TZh+TZm) )%interval )) # test value
t=$(echo $t | tr -d -) # abs($t)
[[ $t -gt 120 ]] && exit 0 # it's not time yet to measure; 120 s tolerance for busy OS failing to start cron on time

cron_data=$cron_dir'/log/'$cron_log_string'_'$id # file name to write to
if [ "$newLog24" == "true" ]; then # file rotation
	if [[ "$cron_new_log_at" =~ ^([0-9]|1[0-9]|2[0-3])$ ]]; then # valid user input
		threshold=$(( now - now%86400 + $cron_new_log_at*3600 - (TZh+TZm) ))
		[[ $now -gt $threshold ]] && let "threshold += 86400"
		cfg=${cfg/$id/$threshold}
		echo $cfg > $cron_cfg
		if [ "$?" -ne 0 ]; then exit 3; fi
		$id=$threshold
		cron_data=$cron_dir'/log/'$cron_log_string'_R_'$threshold # file name to write to; _R_ for rotation file
	else exit 2 # invalid user input
	fi
fi

/var/www/homelab/cgi-bin/get_pH.sh -f $cron_dir'/cron_last' # writes data to file
if [ "$?" -ne 0 ]; then exit 4; fi

echo "cron_data_file='$cron_data'" >> $cron_dir'/cron_last'

while IFS='' read -r line; do eval "$line"; done < $cron_dir'/cron_last' # set variables: $v, $t, $pH, $time, $calibID, $calibDate, $jsonStr, $cron_data_file

# first_line='{"id":'$id',"description":"'$description'","interval":'$interval',"aPointAt":'$aPointAt',"data":['
first_line=$(echo $cfg | sed -r 's/(.*)\}/\1/')',"data":['
if [ ! -f $cron_data ]; then
	echo $first_line >> $cron_data
	echo $jsonStr >> $cron_data
	echo ']}' >> $cron_data
else
	sed -i "1s/.*/${first_line}/" $cron_data # replace the first line; in case the job settings were altered
	sed -i "$ i ,${jsonStr}" $cron_data # insert the new data before the last line -> ']}'
fi

if [ -f cron_more.sh ]; then # bash script to format additional output
. ./cron_more.sh
fi

exit 0
