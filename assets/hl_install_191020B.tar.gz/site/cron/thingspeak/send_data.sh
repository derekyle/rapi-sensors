#!/bin/bash

# writes to Thingspeak

# measured data to Thingspeak fields correspondence:
# pH - field1; pH
#  t - field2; temperature
#  v - field3; voltage

# -- config --

# max number of lines per buffer; a line - a data set
# will attach 1 more line if current measurement is successful
# 5 min measurement interval gives 288 lines per day
# should be less than 960 for Thingspeak free account
data_sets_max=600

# temporary files dir
tmp='/var/www/homelab/cgi-bin/data/cron'

# substring to name buffers
# buffers file names: 'data_to_send-X' where X is incremented integer
buffer_name_string=$tmp'/send_to_thingspeak'

# sets $channel_id, $write_api_key, $field_number_pH, $field_number_temperature, $field_number_voltage
script_path=$(dirname ${BASH_SOURCE[0]}) # this script dir
. $script_path'/channel_config.sh'

# ------------

shopt -s nullglob # nullglob option makes the array empty if there are no matches
arr=($buffer_name_string''*)
if [ "${#arr[@]}" -gt 0 ]; then
	IFS=$' ' sorted=($(sort <<<"${arr[*]}"))
	buffer_to_send=${sorted[0]} # buffer to send to Thingspeak
	buffer_to_write=${sorted[-1]} # buffer to write measurement to ; error if $sorted is empty
	let "lines=$(wc -l < $buffer_to_write)+1" # number data sets in buffer
	if [ "$lines" -gt "$data_sets_max" ]; then
		let "idx=${buffer_to_write##*-}+1"
		buffer_to_write=$buffer_name_string'-'$idx # buffer to write measurement to
	fi
else
	buffer_to_write=$buffer_name_string'-1' # buffer to write measurement to
fi

if [ ! -z ${buffer_to_send+x} ]; then
	updates_str=$(cat $buffer_to_send)
fi

fields_str='{'
field_pH=$(echo "$pH" | grep "^[-,+]\{0,1\}[0-9]\{1,\}\.\{0,1\}[0-9]*$")
if [ "$?" -eq 0 ]; then fields_str=$fields_str'"field'$field_number_pH'":'$field_pH','; fi

field_t=$(echo "$t" | grep "^[-,+]\{0,1\}[0-9]\{1,\}\.\{0,1\}[0-9]*$")
if [ "$?" -eq 0 ]; then 
	[ $temperature_scale == 'Fahrenheit' ] && field_t=$(LC_NUMERIC=C echo "32+$field_t*9/5" | bc -l)
	fields_str=$fields_str'"field'$field_number_temperature'":'$field_t','
fi

field_v=$(echo "$v" | grep "^[-,+]\{0,1\}[0-9]\{1,\}\.\{0,1\}[0-9]*$")
if [ "$?" -eq 0 ]; then fields_str=$fields_str'"field'$field_number_voltage'":'$field_v','; fi

if [ "$fields_str" != '{' ]; then
	created_at=$(date -d @$time +'%Y-%m-%d %H:%M:%S %z')
	fields_str=$fields_str'"created_at":"'$created_at'"}'
	if [ "$updates_str" != '' ]; then
		updates_str=$updates_str','$fields_str
	else
		updates_str=$fields_str
	fi
fi

if [ "$updates_str" == '' ]; then
	echo 'error Thingspeak: No valid data.'
	exit 1
fi

url="https://api.thingspeak.com/channels/$channel_id/bulk_update.json"
write_str='{"write_api_key":"'$write_api_key'","updates":['$updates_str']}'

res=$(curl -s -w '%{http_code}' -H "Cache-Control: no-cache, no-store, must-revalidate" -H "Content-Type: application/json" -X POST -d "$write_str" $url)
# res='000' means 'No valid HTTP response code', ie connection failed (occurs when disconnected)

if [[ "$res" =~ "html>" ]]; then
	http_c=${res/*html\>/} # HTTP status code of html response
	error_string='html response; status code is '$http_c
else
	http_c=${res/*\}/} # HTTP status code of json response
	error_string=${res/\}\}*/\}\}}
fi

if [[ "$http_c" > 299 || "$http_c" < 200 ]]; then # sending has been unsuccessful
	if [ "$http_c" != '000' ]; then # '000' not included as error, assumed intentionally works offline
		echo $(date +'%Y-%m-%d %H:%M:%S %z') $error_string >> $tmp'/thingspeak_error.log' # json response
	fi
	if [ "$fields_str" != '{' ]; then
		if [ -f "$buffer_to_write" ]; then fields_str=','$fields_str; fi
		echo $fields_str >> $buffer_to_write
	fi
	exit 1
fi
rm -f $buffer_to_send # sending has been successful
exit 0
