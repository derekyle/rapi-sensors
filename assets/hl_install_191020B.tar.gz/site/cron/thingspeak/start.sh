/var/www/homelab/cron/add_to_more.sh ". ./thingspeak/send_data.sh"
