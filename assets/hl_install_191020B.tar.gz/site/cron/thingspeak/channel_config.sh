#!/bin/bash

# Thingspeak channel data config file
# (Register a Thingspeak account in advance.)

temperature_scale='Celsius' # value other than 'Fahrenheit' will default to Celsius

# --- Optional (if not set or invalid the Thingspeak defaults will be used)
# colour values are in CSS (RGB) notation
number_of_points=70 # integer between 1 and 3000
line_colour_pH='d62020'
line_colour_temperature='D2691E'
line_colour_voltage='C71585'
auto_refresh=true # true or false
bgcolor='F5F5F5'

# --- Required
line_type='spline' # valid values: 'line', 'bar', 'column', 'spline', 'step';

# --- Required (change the values to be equal to those at the thingspeak.com account)
channel_id='000000'
write_api_key='XXXXXXXXXXXXXXXX'
read_api_key='XXXXXXXXXXXXXXXX'
field_number_pH=1 # the number of the field used for the pH data
field_number_temperature=2 # the number of the field used for the temperature data
field_number_voltage=3 # the number of the field used for the voltage data