#!/bin/bash

# removes a line of code from cron_more.sh
# code set as $1
# code for Thingspeak -> '. ./thingspeak/send_data.sh'

pattern=$1
file='/var/www/homelab/cron/cron_more.sh'
n=$(grep -n "^$pattern$" $file | grep -Eo '^[^:]+') # line number
if [ "$n" != "" ]; then
	str=$n'd'
	sed -i "$str" $file
	sed -i '/^ *$/d' $file
fi
exit 0