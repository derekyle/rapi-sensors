#!/bin/bash
# the code here is executed after cron.sh is finished
# exposed data variables: $v, $t, $pH, $time, $calibID, $calibDate, $jsonStr
