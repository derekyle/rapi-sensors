#!/bin/bash

# add a line to cron_more.sh
# the line code is get as $1 parameter string to this file
# the code would execute a task just after /var/www/homelab/cron_more.sh has been executed
# for Thingspeak.com add '. ./thingspeak/cron.sh'

# $1 || exit 1
pattern=$1
add_to_file='/var/www/homelab/cron/cron_more.sh'
n=$(grep -n "^$pattern$" $add_to_file | grep -Eo '^[^:]+') # line number
if [ "$n" == "" ]; then
	printf "\n$pattern" >> $add_to_file
fi
exit 0