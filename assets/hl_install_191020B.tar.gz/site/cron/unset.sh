#!/bin/bash
#
# removes from crontab a cron job for PUM
# execute with sudo

cd $(dirname "$0")
server_user=www-data
cron_flag='/var/www/homelab/cgi-bin/data/cron/running'
./set_cron.sh -c -q
if [[ $? -eq 0 ]]; then
	echo 'Warning. Cron job is active.'
	./set_cron.sh -r -q
	if [[ $? -eq 1 ]]; then
		echo 'The cron job is cleared.'
		rm $cron_flag
	else
		echo 'Error. Can not clear the cron job.'
		exit 1
	fi
else
	echo 'Can not remove or nothing to remove.'
fi
exit 0
