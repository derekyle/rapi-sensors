#!/bin/bash
#
# set, remove, check the HomeLab cron job of the logged user(logname)

function help {
	echo '--HELP--'
	echo 'Registers crontab job for the "www-data" user.'
	echo 'Execute this as superuser (sudo ...).'
	echo 'Allowed parameters: -s ( --set ), -r ( --remove ),'
	echo '                    -c ( --check ), -h ( --help ), -q ( --quiet ).'
	echo 'Each parameter can be used only once.'
	echo 'All but -q are alternatives and can not be combined.'
	echo 'Parameters after the 2nd are ignored.'
	echo 'Successful exit code for -s is 0 but 1 for -r.'
	echo '$pH_cron_sampling variable holds the sampling interval (-s option)'
	echo 
	echo 'Example:'
	echo 'sudo set_cron.sh -s -q   # Set the cron job quietly - no print.'
	echo '--------'
}

cron_file="/var/www/homelab/cron/cron.sh"
user_name=www-data
task='set'
quiet='false'
# if [ "$1" != '' ]; then
	case $1 in
		-s | --set )
			;;
		-c | --check )
			task='check'
			;;
		-r | --remove )
			task='remove'
			;;
		-q | --quiet )
			quiet='true'
			;;
		-h | --help )
			help
			exit 0
			;;
		* )
			help
			exit 1
			;;
	esac
# fi

if [ "$2" != '' ]; then
	if [ "$quiet" == 'true' ]; then
		case $2 in
			-s | --set )
				task='set'
				;;
			-c | --check )
				task='check'
				;;
			-r | --remove )
				task='remove'
				;;
			* )
				help
				exit 1
				;;
		esac
	else
		if [ "$2" != "-q"  ] && [ "$2" != "--quiet" ]; then
			help
			exit 1
		else quiet='true'
		fi
	fi
fi

export check_quiet='-q'
if [ "$quiet" == 'false' ]; then
	export check_quiet=' '
fi

case $task in
	set )
		task='set'
		;;
	check )
		crontab -l -u $user_name | grep -q "$cron_file"
		check_res=$?
		if [ "$quiet" == 'false' ]; then
			if [ "$check_res" -eq 0 ]; then
				echo 'Present'
				crontab -l -u $user_name | grep "$cron_file" # just to print
			else
				echo 'Not present'
			fi
		fi
		exit $check_res
		;;
	remove )
		crontab -u $user_name -l | grep -v "$cron_file"  | crontab -u $user_name -
		$0 --check $check_quiet
		exit $?
		;;
	* )
		echo 'Something is wrong with this script.'
		exit 1
		;;
esac

if [ "$quiet" == 'false' ]; then
	$0 --check $check_quiet
	if [ "$?" -eq 0 ]; then
		echo -n "HomeLab cron job exists. Overwrite? (Y/n) > "
		read response
		if [[ $response =~ ^([nN])$ ]]; then
			exit 0
		fi
	fi
fi

(crontab -l -u $user_name ; echo "0,5,10,15,20,25,30,35,40,45,50,55 * * * * $cron_file") | crontab -u $user_name -;
export pH_cron_sampling=5 # min; variable to export sampling interval to all calling processes
$0 --check $check_quiet
exit $?