#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

# get filename as $request
. ./get_client_request.sh

if [ -z $request ]; then # no filename sent
	echo '{"error":"no parameters"}'
	exit 1
fi

# : <<'BUTTON'
. ./get_button_state.sh # sets $error, $is_pressed
if [ $? -eq 1 ]; then # something went wrong
	error_str='Geting button state failed.'
	echo '{"error":"'$error_str'"}'
	exit 1
fi

if ! [ -z $error ]; then # exporting the gpio failed
	echo '{"error":"'$error'"}'
	exit 1
fi

if [ "$is_pressed" != "true" ]; then
	echo '{"pass":false}'
	exit 0
fi
# BUTTON

. ./main_config.sh # get $log_path
. ./cron_config.sh # get $cron_dir $cron_log_string
if [[ $request = *"$cron_log_string"* ]]; then
	path=$cron_dir'/log'
else
	path=$log_path
fi

res=$(rm $path'/'$request 2>&1)
if [ "$?" -gt 0 ]; then
	echo '{"error":"'$res'"}'
	exit 1
fi

echo '{"pass":true}'
exit 0