#!/bin/bash

# switch off indicator

echo "Content-Type: application/json;charset=utf-8";
echo

. ./main_config.sh # assign $button_request_interval, $gpio_path, $user_list_file

if [ ! -e $gpio_path'/export' ]; then
	echo '{"taskStatus":"error: no gpio driver"}'
	exit 1
fi

new_list=()
if [ -e $user_list_file ]; then
	now=$(date +%s.%N)
	readarray clients_times < $user_list_file
	for val in ${clients_times[@]}
	do
		res=$(echo "$now-$val < $button_request_interval" | bc)
		if [ $res -eq 1 ]; then new_list=("${new_list[@]}" "$val");	fi # add valid users
	done
fi

if [ ${#new_list[@]} -eq 0 ]; then # no valid users
	if ! [ -e $GPIO_button ]; then
		echo $GPIO_number_button > $gpio_path'/export'
	fi
	sleep 0.05
	rm -f $user_list_file

	source $load_time_config_file # get LEDoff: low|high
	echo $LEDoff > $GPIO_button'/direction'
fi

echo '{"taskStatus":"ok","users":"'${#new_list[@]}'"}'
exit 0
