#!/bin/bash
# cron config data

# --- Do not change the following block of settings ---

cron_dir='/var/www/homelab/cgi-bin/data/cron'
cron_cfg='/var/www/homelab/cgi-bin/data/cron.cfg' # cron job config file, content is set by VI
cron_flag=$cron_dir'/running'
cron_log_string='cron_data' # cron data file base string
allowed_cron_intervals=' 300 900 1800 3600 7200 18000 43200 48400 ' # in seconds; changes to be reflected in the index.html file as well

# ---------

# --- The following settings may be managed by the user ---

# Set a full hour at which to close the old and start a new log file (24 hours file rotation).
# To use or not 24 hour file rotation is controlled by the visual interface, default is NO.
# There may be a gap between the server and your local (client) time.
# Set the value below as server time (i.e. GMT/UTC, check it by 'date' command at the console).
cron_new_log_at=2

# ---------
