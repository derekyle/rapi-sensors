#!/bin/bash

# read the on-board button state
# sets the boolean variable $is_pressed

. ./main_config.sh # set $gpio_path, $GPIO_number_button, $GPIO_button

if [ ! -e $gpio_path'/export' ]; then
	error='No gpio driver.'
	return
fi

if ! [ -e $GPIO_button ]; then
	echo $GPIO_number_button > $gpio_path'/export'
fi

echo "in" > $GPIO_button'/direction'
button_status=$(cat $GPIO_button'/value')
echo "out" > $GPIO_button'/direction'

source $load_time_config_file # set $button_pressed

if [ "$button_status" -eq "$button_pressed" ]; then
	is_pressed='true'
else
	is_pressed='false'
fi
