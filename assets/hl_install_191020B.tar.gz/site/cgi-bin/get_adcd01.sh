#!/bin/bash
###############################
# to be called with set $i2c_bus_number, $conv_buffer, $err_dlmt

# Initialize
_CQUE=0x0300  # Disable the comparator and put ALERT/RDY in high state (default)
_DR=0x8000  # 1600 samples per second
_OS=0x0080  # Write: Set to start a single-conversion
_MODE=0x0001  # Power-down single-shot mode (default)
_MUX=0x0000  # Differential P = AIN0, N = AIN1 (default)
_PGA_256=0x000A  # +/-0.256V range address
_PGA_512=0x0008  # +/-0.512V range address
_PGA_1024=0x0006  # +/-1.024V range address
_PGA_2048=0x0004  # +/-2.048V range address
_REG_CONVERT=0x00
_REG_CONFIG=0x01
_ADC_ADDRESS=0x49 # this is for v1.0+
_RANGE_1=256  # +/-0.256V range
_RANGE_2=512  # +/-0.512V range
_RANGE_3=1024  # +/-1.024V range
_RANGE_4=2048  # +/-2.048V range
_BITS_SPAN=2047 # bits full scale

function get {

	_PGA=$1

	set_bytes=$(printf "0x%04x\n" $(($_MUX | $_PGA | $_MODE | $_DR | $_CQUE)))
	start_bytes=$(printf "0x%04x\n" $(($_OS | set_bytes)))

	res=$(i2cset -y $i2c_bus_number $_ADC_ADDRESS $_REG_CONFIG $set_bytes w 2>&1) # ��������� �� conig reg.
	if [ $? -ne 0 ]; then
		printf "\nerrorV=\"adc-set$err_dlmt${res//\`/}\"\n" >> $conv_buffer
		return 1
	fi
	
	res=$(i2cset -y $i2c_bus_number $_ADC_ADDRESS $_REG_CONFIG $start_bytes w 2>&1) # ����� � conig reg. �� ���������� �� ���������
	if [ $? -ne 0 ]; then
		printf "\nerrorV=\"adc-start$err_dlmt${res//\`/}\"\n" >> $conv_buffer
		return 2
	fi
	sleep 0.02

	res=$(i2cget -y $i2c_bus_number $_ADC_ADDRESS $_REG_CONVERT w 2>&1)
	if [ $? -ne 0 ]; then
		printf "\nerrorV=\"adc-read$err_dlmt${res//\`/}\"\n" >> $conv_buffer
		return 3
	else
		mb=$(echo $res | cut -c3)
		sb=$(echo $res | cut -c5-6)

		res1=$(printf "%d\n" "0x0"$sb$mb)
		if [ $res1 -gt $_BITS_SPAN ]; then
			bits=$(($res1-4096))
		else
			bits=$res1
		fi
	fi
	return 0
}

bits=0
get $_PGA_256 || exit 1
if [ ${bits#-} -lt 2040 ]; then # ${bits#-} absolute value
	range=$_RANGE_1
else
	get $_PGA_512 || exit 1
	if [ ${bits#-} -lt 2040 ]; then
		range=$_RANGE_2
	else
		get $_PGA_1024 || exit 1
		if [ ${bits#-} -lt 2040 ]; then
			range=$_RANGE_3
		else
			get $_PGA_2048 || exit 1
			range=$_RANGE_4
		fi
	fi
fi

v_raw=$(LC_ALL=C printf "%.2f\n" $(echo "$bits*$range/$_BITS_SPAN" | bc -l))
printf "\nv_raw=$v_raw\nrange=$range\ntime=$(date +%s.%N | cut -b1-14)\n" >> $conv_buffer
