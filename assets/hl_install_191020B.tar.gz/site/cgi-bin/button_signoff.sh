#!/bin/bash

# read button

echo "Content-Type: application/json;charset=utf-8";
echo

# get id
. ./get_client_request.sh
IFS='&' read -ra arr <<< "$request"
id=${arr[0]}

if [ -z $id ]; then # no id sent
	echo '{"taskStatus":"error: not allowed"}'
	exit 1
fi

. ./main_config.sh # assign $button_request_interval, $gpio_path, $user_list_file

new_list=()
if [ -e $user_list_file ]; then
	now=$(date +%s.%N)
	readarray clients_times < $user_list_file
	for val in ${clients_times[@]}
	do
		if [ "$val" == "$id" ]; then  # id of a valid user
			valid_user=1
		else
			res=$(echo "$now-$val < $button_request_interval" | bc)
			if [ $res -eq 1 ]; then new_list=("${new_list[@]}" "$val");	fi # add valid users
		fi
	done
fi

if [ -z valid_user ]; then # user - not allowed
	echo '{"taskStatus":"error: not allowed"}'
	exit 2
fi

if [ ${#new_list[@]} -eq 0 ]; then # no valid users
	rm -f $user_list_file
	source $load_time_config_file # get LEDoff: low|high
	echo $LEDoff > $GPIO_button'/direction'
else
	printf "%s\n" "${new_list[@]}" >| $user_list_file
fi

echo '{"taskStatus":"ok","users":"'${#new_list[@]}'","id":"'$id'"}'
exit 0
