#!/bin/bash

# write calibration data

echo "Content-Type: application/json;charset=utf-8";
echo

# get data
. ./get_client_request.sh

if [ -z $request ]; then # no id sent
	echo '{"taskStatus":"error: no data"}'
	exit 1
fi

IFS='&' read -ra arr <<< "$request"

if [ -z ${arr[1]} ]; then # no id sent
	echo '{"taskStatus":"error: wrong data"}'
	exit 2
fi

id=${arr[0]}
ccalib_data=${arr[1]}

. ./main_config.sh # assign $calib_userid_file, $curr_calib_file
calib_user_id="$(cat $calib_userid_file)"

if [ "$calib_user_id" != "$id" ]; then # id of an invalid user
	echo '{"taskStatus":"error: not allowed"}'
	exit 3
fi

echo $ccalib_data >| $curr_calib_file
echo '{"taskStatus":"ok"}'
exit 0