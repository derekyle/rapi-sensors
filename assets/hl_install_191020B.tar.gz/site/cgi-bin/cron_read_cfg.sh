#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

thingspeak_dir='/var/www/homelab/cron/thingspeak'
if [ -d $thingspeak_dir ]; then # directory exists means software installed, otherwise - not installed
	pattern='. ./thingspeak/send_data.sh'
	file='/var/www/homelab/cron/cron_more.sh'
	n=$(grep -n "^$pattern$" $file | grep -Eo '^[^:]+') # line number
	if [ "$n" == "" ]; then # software installed, but not started
		thingspeak_str='"thingspeak":{"running":false},'
	else
		source $thingspeak_dir'/channel_config.sh' # sets thingspeak config values
		thingspeak_str='"thingspeak":{"running":true,
			"fieldNumber":{
				"pH":"'$field_number_pH'",
				"t":"'$field_number_temperature'",
				"v":"'$field_number_voltage'"
			},
			"lineColour":{
				"pH":"'$line_colour_pH'",
				"t":"'$line_colour_temperature'",
				"v":"'$line_colour_voltage'"
			},
			"lineType":"'$line_type'",
			"autoRefresh":"'$auto_refresh'",
			"bgcolor":"'$bgcolor'",
			"numberOfPoints":"'$number_of_points'",
			"channelID":"'$channel_id'",
			"readAPIkey":"'$read_api_key'"
		},'
	fi
fi

source cron_config.sh # sets $cron_cfg $cron_flag $cron_log_string $allowed_cron_intervals $cron_new_log_at
[[ "$cron_new_log_at" =~ ^([0-9]|1[0-9]|2[0-3])$ ]] && newLogAt_str='"newLogAt":'$cron_new_log_at',' # validate integer 0-23 
unassisted=false
[[ -f $cron_flag ]] && unassisted=true
str=$thingspeak_str''$newLogAt_str'"unassisted":'$unassisted',"logFilePrefix":"'$cron_log_string'_","allowedIntervals":"'$allowed_cron_intervals'","offsetToUTC":"'$(date +"%z")'","time":"'$(date +%s%N | cut -b1-13)'"'
cfg=$(cat $cron_cfg 2>&1)
if [ $? -eq 0 ]; then
	echo '{'$str',"config":'$cfg'}'
else
	echo '{'$str',"configError":"'$cfg'"}'
fi
