#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

. ./main_config.sh # sets $log_path
singles_list=$(ls -m -Q $log_path | sort )

source cron_config.sh # sets $cron_dir
unassist_list=$(ls -m -Q $cron_dir'/log' | sort )

if [ "$unassist_list" != "" ]; then
	if [ "$singles_list" != "" ]; then 
		list='['$singles_list','$unassist_list']'
	else
		list='['$unassist_list']'
	fi
else
	if [ "$singles_list" != "" ]; then 
		list='['$singles_list']'
	else
		list='[]'
	fi
fi

echo $list
