#!/bin/bash

# read buffers data & return in json format

echo "Content-Type: application/json;charset=utf-8";
echo

readarray arr < buffers.txt
echo '{'
	echo '"taskStatus":"ok",'
	echo '"coef10toPower":['${arr[0]}'],'
	echo '"tempToPower":['${arr[1]}'],'

	echo '"buffers":{'
		for (( i = 2 ; i < ${#arr[@]} ; i++ ))
		do
			[[ ${arr[$i]} =~ (\".*\") ]] 
			descr=${BASH_REMATCH[1]}
			data=(${arr[$i]/${BASH_REMATCH[1]}/})

			echo '"'${data[0]}'":{'
			echo '"name":"'${data[0]}'",'
			echo '"pH25C":"'${data[1]}'",'
			echo '"description":'$descr','
			echo '"coef":['${data[2]}','${data[3]}','${data[4]}','${data[5]}']'
			echo '},'
		done
		echo '"toBeDeleted":"just to end properly the buffers object"'
	echo '}'
echo '}'
