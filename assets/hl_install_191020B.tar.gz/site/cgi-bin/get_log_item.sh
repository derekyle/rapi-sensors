#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

# get filename as $request
. ./get_client_request.sh

. ./main_config.sh


if [ -z $request ]; then # no filename sent
	echo '{"taskStatus":"error: no parameters"}'
	exit 1
fi

. /var/www/homelab/cgi-bin/cron_config.sh 2>/dev/null # sets $cron_cfg, $allowed_cron_intervals, $cron_dir, $cron_log_string

if [[ ! -z $cron_log_string && $request =~ $cron_log_string ]]; then
	file=$cron_dir'/log/'$request
else
	file=$log_path'/'$request
fi

res=$(cat $file)
exit_code=$?
if [ "$exit_code" -gt 0 ]; then
	echo '{"taskStatus":"error: exitCode '$exit_code'"}'
	exit 1
fi

echo $res
exit 0