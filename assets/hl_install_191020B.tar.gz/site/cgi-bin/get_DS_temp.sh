#!/bin/bash
# to be called with variables $one_wire_path, $t_sensor_id, $conv_buffer, $err_dlmt set

readt=$(timeout 2 cat $one_wire_path'/'$t_sensor_id'/w1_slave' 2>&1)
exit_code=$?

if [ $exit_code -ne 0 ]; then
	if [ $exit_code -gt 120 ]; then
		printf "\nerrorT=\"bad-bus-response$err_dlmt$exit_code\"\n" >> $conv_buffer
	else
		printf "\nerrorT=\"no-device$err_dlmt$readt\"\n" >> $conv_buffer
	fi
else
	regex=".*YES.*"
	if [[ "$readt" =~ $regex ]]; then
		printf "\ntmpr_str=\""$(expr match "$readt" '.*t=\(.*\)')"\"\n" >> $conv_buffer
	else
		printf "\nerrorT=\"no-response$err_dlmt crc=00\"\n" >> $conv_buffer
	fi
fi
