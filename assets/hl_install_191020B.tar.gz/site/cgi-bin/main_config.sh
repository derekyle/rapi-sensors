#!/bin/bash
# config data

button_request_interval=60

# dir paths
homelab_root='/var/www/homelab'
data_path=$homelab_root'/cgi-bin/data'
data2_path=$homelab_root'/cgi-bin/data2'
log_path=$data_path'/log'
gpio_path='/sys/class/gpio'
i2c_files_path='/usr/sbin'
one_wire_path='/sys/bus/w1/devices'

# file paths
user_list_file=$data_path'/button_requests_list'
curr_calib_file=$data_path'/ccalib_data'
calib_userid_file=$data_path'/calib_user_id'
user_defaults_file=$data_path'/user_defaults'
t_sensor_id_file=$data_path'/t_sensor_id'
load_time_config_file=$data2_path'/load_time_config.sh'