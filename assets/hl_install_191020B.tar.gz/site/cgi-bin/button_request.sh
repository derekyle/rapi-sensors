#!/bin/bash

# button request

echo "Content-Type: application/json;charset=utf-8";
echo

. ./main_config.sh # assign $button_request_interval, $gpio_path, $user_list_file

if [ ! -e $gpio_path'/export' ]; then
	echo '{"taskStatus":"error: no gpio driver"}'
	exit 1
fi

new_list=()
now=$(date +%s.%N)
if [ -e $user_list_file ]; then
	readarray clients_times < $user_list_file
	for val in ${clients_times[@]}
	do
		res=$(echo "$now-$val < $button_request_interval" | bc)
		if [ $res -eq 1 ]; then new_list=("${new_list[@]}" "$val");	fi
	done
fi
new_list=("${new_list[@]}" "$now")
printf "%s\n" "${new_list[@]}" >| $user_list_file
if [ $? -eq 1 ]; then
	echo '{"taskStatus":"error: can not write button request data"}'
	exit 1
fi
if ! [ -e $GPIO_button ]; then
	echo $GPIO_number_button > $gpio_path'/export'
	sleep 0.05
fi

source $load_time_config_file # get LEDoff: low|high
echo $LEDon > $GPIO_button'/direction'

echo '{"taskStatus":"ok","buttonRequestInterval":"'$button_request_interval'","buttonRequestId":"'$now'"}'
exit 0
