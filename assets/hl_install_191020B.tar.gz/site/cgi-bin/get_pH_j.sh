#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

./get_pH.sh -json