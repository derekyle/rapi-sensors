#!/bin/bash

# write t sensor id

echo "Content-Type: application/json;charset=utf-8";
echo

# get id as $request
. ./get_client_request.sh

if [ -z $request ]; then # no id sent
	echo '{"taskStatus":"error: no data"}'
	exit 1
fi

. ./main_config.sh # $t_sensor_id_file

echo $request >| $t_sensor_id_file
exitCode = $?;
if [ "$exitCode" -gt "0" ]; then
	echo '{"taskStatus":"error: exitCode '$exitCode'"}'
	exit 1
fi

echo '{"taskStatus":"ok"}'
exit 0