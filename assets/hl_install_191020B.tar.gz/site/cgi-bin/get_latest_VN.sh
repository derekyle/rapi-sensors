#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo
url='http://homelab.link/ph/meter/software/rpi/latest_version'
file_path='/var/www/homelab/cgi-bin/data/latest_version'
http_code=$(curl -s -o $file_path -w '%{http_code}' -H "Cache-Control: no-cache, no-store, must-revalidate" -H "Content-Type: application/json" -X POST -d '{"currentVersion":"'$(cat '/var/www/homelab/ui/version')'"}' $url)
if [[ $http_code -eq 200 ]]; then
	echo '{"taskStatus":"ok","versionNumber":"'$(cat $file_path)'"}'
	exit 0
else
	echo '{"taskStatus":"bad","httpCode":"'$http_code'"}'
	exit 1
fi
