if [ "$REQUEST_METHOD" = "GET" ]; then
	request="$QUERY_STRING"
fi

if [ "$REQUEST_METHOD" = "POST" ]; then
    if [ "$CONTENT_LENGTH" -gt 0 ]; then
        read -r -n $CONTENT_LENGTH request <&0
    fi
fi
