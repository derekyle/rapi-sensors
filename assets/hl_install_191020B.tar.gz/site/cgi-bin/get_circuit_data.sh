#!/bin/bash

# read EEPROM data & return in json format
# data - according Spec ver 1,2 and 3

echo "Content-Type: application/json;charset=utf-8";
echo

cd "$(dirname "$0")" #  change to file's directory

. ./main_config.sh # $data2_path, $i2c_files_path
PATH=$PATH":"$i2c_files_path

# search for available i2c-bus 1; looks in i2cdetect return string
i2cdetect -l | grep -e "i2c-1[[:blank:]]*i2c" >/dev/null 2>&1
if [ $? -ne 0 ]; then  # no bus
	echo '{"taskStatus":"error: i2c-bus 1 not found."}'
	exit 1
fi

# search for HL modules attached to i2c-bus 1 only
# will return error if 0 or >1 are found
# eeprom i2c-addresses supported: 0x59 0x5b
i2c_bus_number=1 # bus 1
i2c_eeprom_address=
__found=0
for __el in 5b 51; do
	case $__el in
		5b)
			__id=$(i2cget -y $i2c_bus_number 0x5b 0x00 w 2>/dev/null) # read the HL string Rev 4
			;;
		51)
			__id=$(i2cget -y $i2c_bus_number 0x51 0x0a w 2>/dev/null) # read the HL string Rev1-3
			;;
	esac
	if [ ! -z "$__id" ]; then
		__id=$(echo $__id | xxd -r -p) # HEX to ASCII
		if [ "$__id" == "LH" ]; then 
			i2c_eeprom_address='0x'$__el
			let "__found++"
		fi
	fi
done
case $__found in
	0)
		echo '{"taskStatus":"error: No board or no board data"}'
		exit 1
	;;
	2)
		echo '{"taskStatus":"error: Only one board is allowed. More found."}'
		exit 1
	;;
esac

spec_version=$(printf '%d' "$(i2cget -y $i2c_bus_number $i2c_eeprom_address | cut -c3-4)")
for val in `seq 0 4`; do
	boardId=("$boardId"$(i2cget -y $i2c_bus_number $i2c_eeprom_address | cut -c3-4))
done
boardRev=${boardId:2:2}

case $spec_version in
	1)
		for val in `seq 0 15`; do
			d=("${d[@]}" $(echo -e "\x"$(i2cget -y $i2c_bus_number $i2c_eeprom_address | cut -c3-4)))
		done
		offset=$(echo ${d[1]}${d[2]}.${d[3]}${d[4]} | sed 's/^0//') # remove leading 0
		offset=${d[0]}$offset
		mult=${d[5]}.${d[6]}${d[7]}${d[8]}${d[9]}${d[10]}
		R1=${d[11]}${d[12]}${d[13]}.${d[14]}${d[15]}
		;;
	2)
		for val in `seq 0 19`; do
			d=("${d[@]}" $(echo -e "\x"$(i2cget -y $i2c_bus_number $i2c_eeprom_address | cut -c3-4)))
		done
		offset=$(echo ${d[1]}${d[2]}.${d[3]}${d[4]} | sed 's/^0//') # remove leading 0
		offset=${d[0]}$offset
		mult=${d[5]}.${d[6]}${d[7]}${d[8]}${d[9]}
		R1=${d[10]}${d[11]}${d[12]}.${d[13]}${d[14]}
		RII=${d[15]}${d[16]}${d[17]}.${d[18]}${d[19]}
		;;
	3)
		for val in `seq 0 5`; do
			d=("${d[@]}" "$(i2cget -y $i2c_bus_number $i2c_eeprom_address | cut -c3-4)")
		done
		LC_ALL=C
		offset=$(printf "%.1f\n" $(echo "$((0x${d[0]}))/10-10" | bc -l))
		mult=$(echo ${d[1]:0:1}.${d[1]:1:1}${d[2]}${d[3]:0:1})
		R1=$(printf "%.2f\n" $(echo "$((0x${d[4]}))/100+129" | bc -l))
		RII=$(printf "%.2f\n" $(echo "$((0x${d[5]}))/100+129" | bc -l))
		;;
	*)
		echo '{"taskStatus":"error: Invalid spec version."}'
		exit 1
esac

case $boardRev in # LED & button on/off is reversed for R1.1
11*)
	printf "\nLEDoff='high'\nLEDon='low'\nbutton_not_pressed=0\nbutton_pressed=1" > $data2_path/load_time_config.sh
	;;
*)
	printf "\nLEDoff='low'\nLEDon='high'\nbutton_not_pressed=1\nbutton_pressed=0" > $data2_path/load_time_config.sh
	;;
esac
chmod 777 $data2_path/load_time_config.sh
echo '{'
echo '"taskStatus":"ok",'
echo '"offset":"'$offset'",' # bug??: does not return zero before the decimal point
echo '"mult":"'$mult'",'
echo '"specVersion":"'$spec_version'",'
echo '"R1":"'$R1'",'
if [ "$spec_version" -gt 1 ]; then echo '"RII":"'$RII'",'; fi
echo '"boardId":"'$boardId'"'
echo '}'
