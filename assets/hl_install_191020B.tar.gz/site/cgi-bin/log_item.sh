#!/bin/bash

# write a measurement data

echo "Content-Type: application/json;charset=utf-8";
echo

# get data as $request
. ./get_client_request.sh

if [ -z $request ]; then
	echo '{"taskStatus":"error: no parameters"}'
	exit 1
fi

IFS='&' read -ra arr <<< "$request"

if [ -z ${arr[1]} ]; then # no second token
	echo '{"taskStatus":"error: no data"}'
	exit 2
fi

filename=${arr[0]}
meas_data=${arr[1]}

. ./main_config.sh # $log_path

echo $meas_data > $log_path'/'$filename
exitCode = $?;
if [ "$exitCode" -gt "0" ]; then
	echo '{"taskStatus":"error: exitCode '$exitCode'"}'
	exit 1
fi

echo '{"taskStatus":"ok"}'
exit 0