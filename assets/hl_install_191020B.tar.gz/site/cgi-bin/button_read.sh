#!/bin/bash

# read button

echo "Content-Type: application/json;charset=utf-8";
echo

. ./main_config.sh # assign $button_request_interval, $gpio_path, $user_list_file

if [ ! -e $gpio_path'/export' ]; then
	echo '{"taskStatus":"error: no gpio driver"}'
	exit 1
fi

new_list=()
now=$(date +%s.%N)
if [ -e $user_list_file ]; then
	readarray clients_times < $user_list_file
	for val in ${clients_times[@]}
	do
		res=$(echo "$now-$val < $button_request_interval" | bc)
		if [ $res -eq 1 ]; then new_list=("${new_list[@]}" "$val");	fi # add valid users
	done
fi

if [ ${#new_list[@]} -eq 0 ]; then # no valid users
	rm -f $user_list_file
	echo '{"taskStatus":"error: not allowed 2"}'
	exit 2
fi

# get id
. ./get_client_request.sh
IFS='&' read -ra arr <<< "$request"
id=${arr[0]}

if [ -z $id ]; then # no id sent
	echo '{"taskStatus":"error: not allowed 3"}'
	exit 3
fi

for val in ${clients_times[@]}
do
	if [ "$val" == "$id" ]; then valid_user=1; fi # id of a valid user
done

if [ -z $valid_user ]; then # user - not valid
	echo '{"taskStatus":"error: not allowed 4"}'
	exit 4
fi

if ! [ -e $GPIO_button ]; then
	echo $GPIO_number_button > $gpio_path'/export'
fi

echo "in" > $GPIO_button'/direction'
button_status=$(cat $GPIO_button'/value')

source $load_time_config_file # get LEDoff command: low|high & button_not_pressed value

if [ "$button_status" -eq "$button_not_pressed" ]; then # button not pressed
	if [ ${#new_list[@]} -ne ${#clients_times[@]} ]; then
		printf "%s\n" "${new_list[@]}" > $user_list_file # overwrite file
	fi
	echo '{"taskStatus":"ok","buttonStatus":"0"}'
	exit 0
fi

rm $user_list_file
if [ "$?" -ne 0 ]; then # no file - deleted meanwhile by earlier user
	echo '{"taskStatus":"error: not allowed 5"}'
	exit 5
fi

echo $LEDoff > $GPIO_button'/direction'
echo $id > $calib_userid_file
echo '{"taskStatus":"ok","buttonStatus":"1"}'
exit 0
