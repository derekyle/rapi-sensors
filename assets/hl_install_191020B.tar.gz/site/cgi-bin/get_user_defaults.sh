#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

. ./main_config.sh

echo $(cat $user_defaults_file)
exit 0