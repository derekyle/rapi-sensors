#!/bin/bash

# Filters Homelab-pH data output and prints console or json formated strings or writes to a file
# Homelab.link; v.180521

# Notes:
# file location: /var/www/homelab/cgi-bin/  
# file permissions: 0555
#	
# Exits if no board found
# Outputs json-formated data if the first argument is -json or -j
# Writes data to a file if the first argument is -file or -f. The second argument is the file path.
#
# 't' is in Celsius
# 'v' is in mV
# 'time' is UNIX Epoch time in seconds
#
#	'bc' module has to be available

cd "$(dirname "$0")" # all links are local to the file location

# init vars
# -----------
ouputFormat='console'
if [ "$1" == "-json" ] || [ "$1" == "-j" ]; then ouputFormat='json'; fi # will print json-formated string
if [ "$1" == "-file" ] || [ "$1" == "-f" ]; then ouputFormat='file'; fi # to file
initStr='skipped'
[[ $ouputFormat == 'json' ]] && initStr='false' # !'false' - boolean for numericals while string for strings
NERNST=0.19842
ABSZERO=273.15
scripts_dir='/var/www/homelab/cgi-bin'

# output vars
taskStatus=ok
errorStrings=''
time=$(date +%s.%N | cut -b1-14)
v=$initStr
t=$initStr
calibID=$initStr
pH=$initStr
calibDate=$initStr

# functions
# -----------

function addError {
	errStr=$1
	if [ "${#errorStrings}" -gt "1" ]; then
		errorStrings=$errorStrings',"'$errStr'"'
	else
		[[ $ouputFormat == 'json' || $ouputFormat == 'file' ]] && errorStrings='['
		errorStrings=$errorStrings'"'$errStr'"'
	fi
}

function writeOutput {
	[ "${#errorStrings}" -gt "0" ] && jsonError='"errorStrings":'$errorStrings'],'
	case $ouputFormat in
		json )
			echo '{"taskStatus":"'$taskStatus'",'$jsonError'"time":'$time',"v":'$v',"t":'$t',"pH":'$pH',"calibID":"'$calibID'","calibDate":"'$calibDate'"}'
			;;
		console )
			echo "taskStatus=$taskStatus"
			[ "${#errorStrings}" -gt "0" ] && echo "errorStrings=$errorStrings"
			echo "time=$time"
			echo "v=$v"
			echo "t=$t"
			echo "pH=$pH"
			echo "calibID=$calibID"
			echo "calibDate=$calibDate"
			;;
		file )
			str="time=$time\nv=$v\nt=$t\npH=$pH\ncalibID='$calibID'\ncalibDate='$calibDate'"
			if [ "$t" == "skipped" ]; then t=false; fi
			if [ "$pH" == "skipped" ]; then pH=false; fi
#			jsonStr='{"taskStatus":"'$taskStatus'",'$jsonError'"time":'$time',"v":'$v',"t":'$t',"pH":'$pH',"calibID":"'$calibID'","calibDate":"'$calibDate'"}'
			jsonStr='{"taskStatus":"'$taskStatus'",'$jsonError'"time":'$time',"v":'$v',"t":'$t',"pH":'$pH'}' # skips the calibration data - shorter string for unassisted measurements file
			str="$str\njsonStr='$jsonStr'\n"
			printf "$str" > $1 # writes data to file $1
			if [ "$?" -ne 0 ]; then exit 2; fi
			;;
	esac
}

# get and validate data
# -----------

if [ ! -f ./data/ccalib_data ]; then
	addError "warning: No calibration data file"
else
	calibData=$(cat ./data/ccalib_data)

	# calibID string
	calibID=${calibData/*id\":\"/}
	calibID=${calibID/\"*/}

	# coef_B float
	coef_B=${calibData/*coef_B\":/}
	coef_B=${coef_B/,*/}

	# iso_pH float
	iso_pH=${calibData/*iso_pH\":/}
	iso_pH=${iso_pH/,*/}

	# iso_v float
	iso_v=${calibData/*iso_v\":/}
	iso_v=${iso_v/,*/}

	# iso_v float
	calibDate=${calibData/*date\":\"/}
	calibDate=${calibDate/\"*/}

fi

board=$(. ./get_circuit_data.sh 2>/dev/null) # error due to changed dir; to be corrected in get_circuit_data.sh
if [[ $board != *'"taskStatus":"ok"'* ]]; then # board data is not ok
	boardStr=${board/*Status\":\"/} # delete from start
	boardStr=${boardStr/\"*/} # delete end
	addError "$boardStr"
	taskStatus=bad
	writeOutput $2
	exit 1
fi

# offset string
offset=${board/*offset\":\"/}
offset=${offset/\"*/}
offset=${offset/*\+/} # delete plus sign

# mult string
mult=${board/*mult\":\"/}
mult=${mult/\"*/}

. ./get_t_sensors.sh # sets $status, $sensors, $match; calls also main_config.sh

if [[ "$status" == *"no sensors"* ]]; then # test sensor is attached
	addError 'warning: No temperature sensor found'
else
#	request="" # sensor id
	if [ "${#sensors[@]}" -gt "1" ]; then
		warn="warning: Multiple temperature sensors found."
		if [[ $match ]]; then request=$match # $request is used by get_data.sh
		else warn=$warn" Select by the visual interface."
		fi
		addError "$warn"
	else request=${sensors[0]}
	fi
fi

. ./get_data.sh # needs $request

# calculate 
# -----------
LC_ALL=C 
# voltage
v=$(bc -l <<< "scale=6;($v_raw- $offset)/$mult") # space matters
v=$(printf "%.*f\n" 1 $v) # print floats<0 with prepaded zero

if [ -z "$errorT" ]; then 

	# temperature
	t=$(echo "$tmpr_str/1000" | bc -l)
	t=$(printf "%.*f\n" 1 $t)

	if [ -f ./data/ccalib_data ]; then
		# pH
		pH=$(echo "( $v - $iso_v ) / ( $coef_B * $NERNST * ( $t + $ABSZERO ) ) + $iso_pH" | bc -l)
		pH=$(printf "%.*f\n" 2 $pH)
	fi

else addError "error: $errorT"
fi

writeOutput $2
exit 0