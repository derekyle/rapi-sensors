#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

. ./get_client_request.sh # get config data as $request

if [ -z $request ]; then # no data sent
	echo '{"error":"Saving the config data failed. No data sent."}'
	exit 1
fi

# todo: validate $request - config data

. ./get_button_state.sh # sets $error, $is_pressed
if [ $? -eq 1 ]; then # something went wrong
	echo '{"error":"Geting button state failed."}'
	exit 1
fi

if ! [ -z $error ]; then # exporting the gpio failed
	echo '{"error":"'$error'"}'
	exit 1
fi

if [ "$is_pressed" != "true" ]; then
	echo '{"pass":false}'
	exit 0
fi

if [[ "$request" =~ .*\"id\":\"\".* ]]; then # "id":"" - i.e. not defined
	# $request assumed similar to {"id":"","description":"Whatever user wrote here.","interval":43200,"aPointAt":7200}
	id_str='"id":"'$(date +%s)'"'
	str='"id":""'
	request=$(echo "${request/$str/$id_str}") # replace
fi

. ./cron_config.sh # sets $cron_cfg
write=$(echo $request > $cron_cfg)
if [ $? -eq 0 ]; then
	echo '{"pass":true}'
else
	echo '{"error":"Saving the config data failed. Write error."}'
	exit 1
fi
exit 0
