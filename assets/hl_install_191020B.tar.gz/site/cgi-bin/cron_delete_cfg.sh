#!/bin/bash

echo "Content-Type: application/json;charset=utf-8";
echo

. ./cron_config.sh # sets $cron_cfg

if [ ! -f $cron_cfg ]; then
	echo '{"file":"missing"}'
	exit 1
fi

. ./get_button_state.sh # sets $error, $is_pressed
if [ $? -eq 1 ]; then # something went wrong
	echo '{"error":"Geting button state failed."}'
	exit 1
fi

if ! [ -z $error ]; then # exporting the gpio failed
	echo '{"error":"'$error'"}'
	exit 1
fi

if [ "$is_pressed" != "true" ]; then
	echo '{"pass":false}'
	exit 0
fi

rm $cron_cfg

if [ $? -eq 0 ]; then
	echo '{"pass":true}'
else
	echo '{"file":"failed"}'
	exit 1
fi
exit 0
